<?php
header("Location: ./dist/pages/index.php");
exit();
?>
