<?php
$db_config = [
    'servername' => '127.0.0.1',
    'username' => 'radmon', # Kalo eror ganti jadi radmon
    'password' => 'radmon', # Kalo eror ganti jadi radmon
    'dbname' => 'radmon' # Kalo eror ganti jadi radmon
];
?>
