<?php
/*
*******************************************************************************************************************
* Warning!!!, Tidak untuk diperjual belikan!, Cukup pakai sendiri atau share kepada orang lain secara gratis
*******************************************************************************************************************
* Original Loginpage untuk Mikrotik dibuat oleh @Badaro
*
* Modifikasi Untuk coova-chilli oleh @Maizil https://t.me/maizil41
*******************************************************************************************************************
* © 2024 Mutiara-Net By @Maizil
*******************************************************************************************************************
*/
session_name('hotspot_session');
session_start();

if (headers_sent()) {
    exit();
}

if (isset($_GET['mac'])) {
    $mac = $_GET['mac'];
}

if (!isset($_SESSION['username'])) {
    $isLoggedIn = 1;
}else {
    $isLoggedIn = 0;
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <title>KONTAK</title>
    <link rel="icon" type="image/png" href="../assets/img/favicon.png" sizes="32x32">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<!-- App Header -->
<div class="appHeader">
    <div class="left">
                <?php if ($isLoggedIn == 1): ?>
        <a href="http://10.10.10.1:3990" class="headerButton goBack">
                <?php endif; ?>
                <?php if ($isLoggedIn == 0): ?>
        <a href="../index.php?mac=<?php echo "$mac" ?>" class="headerButton goBack">
                <?php endif; ?>
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="36" height="36" viewBox="0 0 24 24">
			<path fill="#6236FF" d="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z" />
			</svg>
        </a>
    </div>
    
    <!-- * WhatsApp -->
<div class="section mt-2">
    <div class="card">
        <div class="card-body">
            <div class="p-1">
                <div class="text-center">
                    <h2 class="text-primary">Hubungi Lebih Lanjut</h2>
        <ul class="listview image-listview bg-primary mb-2 inset">
            <li>
                <script src="../assets/config/whatsapp.js"></script>
                    <div class="in">
                        <div class="text-white">WhatsApp</div>
                    </div>
					<div>
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="36" height="36" viewBox="0 0 24 24">
						<path fill="#A9ABAD" d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z" />
						</svg>
					</div>
                                 <img src="../assets/img/whatsapp.png" alt="logo" style="height: 25px; width: 25px; border: 0;">
                </a>
            </li>
            <li>
                <script src="../assets/config/tele.js"></script>
                    <div class="in">
                        <div class="text-white">telegram</div>
                    </div>
					<div>
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"  width="36" height="36" viewBox="0 0 24 24">
						<path fill="#A9ABAD" d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z" />
						</svg>
					</div>
                                 <img src="../assets/img/whatsapp.png" alt="logo" style="height: 25px; width: 25px; border: 0;">
                </a>
            </li>
        </ul>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- * WhatsApp -->

    </div>
    <!-- * App Capsule -->
	
    <!-- Bootstrap -->
    <script src="../assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Base Js File -->
    <script src="../assets/js/base.js"></script>

</body>

</html>