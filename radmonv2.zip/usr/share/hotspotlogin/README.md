<h1 align="center">
  LOGINPAGE FOR COOVA-CHILLI
</h1>
<div align="center">
  <a target="_blank" href="https://github.com/Maizil41/hotspotlogin/releases"><img src="https://img.shields.io/badge/Version-1.0-green?style=for-the-badge" alt="Version Badge"></a>
   <a target="_blank" href="https://t.me/mutiara_wrt"><img src="https://img.shields.io/badge/Telegram-Join%20Us-blue?style=for-the-badge&logo=telegram" alt="Join us on Telegram"></a>
</div>
