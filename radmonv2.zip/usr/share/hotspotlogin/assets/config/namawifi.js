document.write('RASYA-AWIRELESS.NET')
//Sesuaikan
//Jangan Menghapus kode scriptnya