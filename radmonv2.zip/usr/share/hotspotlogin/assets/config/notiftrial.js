document.write('WEKTU UJI COBA WES NTEK,SESOK MANEH.PINGIN SUE : <a href="./utilities/wa.php" class="btn btn-text-primary" >hubungi')
//Sesuaikan
//Jangan Menghapus kode scriptnya