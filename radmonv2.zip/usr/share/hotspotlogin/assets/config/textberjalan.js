document.write('PINGIN RODOK SUE?HUB WA KU AE')
//Sesuaikan
//Jangan Menghapus kode scriptnya