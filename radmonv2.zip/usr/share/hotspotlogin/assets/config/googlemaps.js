document.write('<a href="https://goo.gl/maps/b5AvwijHMzcVgSCZA" class="btn btn-dark">Google Maps</a>')
//Sesuaikan LinkGOOGLEMaps dengan link lokasi kantor agan
//Jangan Menghapus kode scriptnya