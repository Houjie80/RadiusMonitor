document.write('<a href="https://wa.me/+6285643273595" class="item"</a>')
//Ganti +6288215748115 dengan NO WhatsApp Agan (Gunakan Kode Negara +62)
//Jangan Menghapus kode scriptnya