-- MariaDB dump 10.19  Distrib 10.9.3-MariaDB, for Linux (aarch64)
--
-- Host: localhost    Database: radmon
-- ------------------------------------------------------
-- Server version	10.9.3-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bandwidth`
--

DROP TABLE IF EXISTS `bandwidth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bandwidth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `rate_down` int(11) DEFAULT 0,
  `rate_up` int(11) DEFAULT 0,
  `creation_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bandwidth`
--

LOCK TABLES `bandwidth` WRITE;
/*!40000 ALTER TABLE `bandwidth` DISABLE KEYS */;
INSERT INTO `bandwidth` VALUES
(1,'Harian',255000,255000,'2024-11-13 01:15:10'),
(2,'Keluarga',7340032,7340032,'2024-11-13 01:15:26');
/*!40000 ALTER TABLE `bandwidth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_history`
--

DROP TABLE IF EXISTS `batch_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_history` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(64) DEFAULT NULL COMMENT 'an identifier name of the batch instance',
  `batch_description` varchar(256) DEFAULT NULL COMMENT 'general description of the entry',
  `hotspot_id` int(32) DEFAULT 0 COMMENT 'the hotspot business id associated with this batch instance',
  `batch_status` varchar(128) NOT NULL DEFAULT 'Pending' COMMENT 'the batch status',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `batch_name` (`batch_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_history`
--

LOCK TABLES `batch_history` WRITE;
/*!40000 ALTER TABLE `batch_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_plans`
--

DROP TABLE IF EXISTS `billing_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_plans` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `planName` varchar(128) DEFAULT NULL,
  `planId` varchar(128) DEFAULT NULL,
  `planType` varchar(128) DEFAULT NULL,
  `planTimeBank` varchar(128) DEFAULT NULL,
  `planTimeType` varchar(128) DEFAULT NULL,
  `planTimeRefillCost` varchar(128) DEFAULT NULL,
  `planBandwidthUp` varchar(128) DEFAULT NULL,
  `planBandwidthDown` varchar(128) DEFAULT NULL,
  `planTrafficTotal` varchar(128) DEFAULT NULL,
  `planTrafficUp` varchar(128) DEFAULT NULL,
  `planTrafficDown` varchar(128) DEFAULT NULL,
  `planTrafficRefillCost` varchar(128) DEFAULT NULL,
  `planRecurring` varchar(128) DEFAULT NULL,
  `planRecurringPeriod` varchar(128) DEFAULT NULL,
  `planRecurringBillingSchedule` varchar(128) NOT NULL DEFAULT 'Fixed',
  `planCost` varchar(128) DEFAULT NULL,
  `planSetupCost` varchar(128) DEFAULT NULL,
  `planTax` varchar(128) DEFAULT NULL,
  `planCurrency` varchar(128) DEFAULT NULL,
  `planGroup` varchar(128) DEFAULT NULL,
  `planActive` varchar(32) NOT NULL DEFAULT 'yes',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  `planCode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `planName` (`planName`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_plans`
--

LOCK TABLES `billing_plans` WRITE;
/*!40000 ALTER TABLE `billing_plans` DISABLE KEYS */;
INSERT INTO `billing_plans` VALUES
(1,'Admin','Admin','Prepaid','','Accumulative','','','','','','','','No','Never','Fixed','0','','','','','yes','2024-11-13 01:06:40','radmon','2024-11-13 01:06:40','radmon','Adm'),
(2,'TRIAL','TRIAL','Prepaid','86400','Accumulative','','','','','','','','No','Never','Fixed','0','','','','','yes','2024-11-13 01:14:08','radmon','2024-11-13 01:14:36','radmon','Tr'),
(3,'Harian','Harian','Prepaid','','Accumulative','','','','','','','','No','Never','Fixed','1000','','','','','yes','2024-11-13 01:16:44','radmon','2024-11-13 01:16:44','radmon','Hr'),
(4,'Mingguan','Mingguan','Prepaid','','Accumulative','','','','','','','','No','Never','Fixed','5000','','','','','yes','2024-11-13 01:17:26','radmon','2024-11-13 01:17:26','radmon','Mg');
/*!40000 ALTER TABLE `billing_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `whatsapp_number` varchar(20) DEFAULT NULL,
  `telegram_id` varchar(50) NOT NULL,
  `balance` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income`
--

DROP TABLE IF EXISTS `income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income` (
  `username` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`date`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income`
--

LOCK TABLES `income` WRITE;
/*!40000 ALTER TABLE `income` DISABLE KEYS */;
/*!40000 ALTER TABLE `income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nasname` varchar(128) COLLATE utf8mb3_unicode_ci NOT NULL,
  `shortname` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8mb3_unicode_ci DEFAULT 'other',
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'secret',
  `server` varchar(64) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `community` varchar(50) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb3_unicode_ci DEFAULT 'RADIUS Client',
  PRIMARY KEY (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operators`
--

DROP TABLE IF EXISTS `operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operators` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operators`
--

LOCK TABLES `operators` WRITE;
/*!40000 ALTER TABLE `operators` DISABLE KEYS */;
INSERT INTO `operators` VALUES
(1,'root','mutiara');
/*!40000 ALTER TABLE `operators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_requests`
--

DROP TABLE IF EXISTS `otp_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otp_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `whatsapp_number` varchar(20) DEFAULT NULL,
  `otp_code` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_requests`
--

LOCK TABLES `otp_requests` WRITE;
/*!40000 ALTER TABLE `otp_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `otp_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_config`
--

DROP TABLE IF EXISTS `print_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `print_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hsname1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hsname2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hsip` varchar(15) DEFAULT NULL,
  `hsdomain` varchar(255) DEFAULT NULL,
  `hscsn` varchar(20) DEFAULT NULL,
  `hsqrmode` varchar(10) DEFAULT NULL,
  `hsipdomain` varchar(10) DEFAULT NULL,
  `logomode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_config`
--

LOCK TABLES `print_config` WRITE;
/*!40000 ALTER TABLE `print_config` DISABLE KEYS */;
INSERT INTO `print_config` VALUES
(1,'𝗠𝗨𝗧𝗜𝗔𝗥𝗔','𝗡𝗘𝗧','10.10.10.1','mutiara.wifi','0853-7268-7484','code','ip','text');
/*!40000 ALTER TABLE `print_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radacct`
--

DROP TABLE IF EXISTS `radacct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radacct` (
  `radacctid` bigint(21) NOT NULL AUTO_INCREMENT,
  `acctsessionid` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `groupname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `realm` varchar(64) COLLATE utf8mb3_unicode_ci DEFAULT '',
  `nasipaddress` varchar(15) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `nasportid` varchar(15) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `nasporttype` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctupdatetime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctinterval` int(12) DEFAULT NULL,
  `acctsessiontime` int(12) unsigned DEFAULT NULL,
  `acctauthentic` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `connectinfo_start` varchar(50) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `connectinfo_stop` varchar(50) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `callingstationid` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `servicetype` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedprotocol` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedipv6address` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedipv6prefix` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedinterfaceid` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `delegatedipv6prefix` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedipaddress` varchar(15) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`radacctid`),
  UNIQUE KEY `acctuniqueid` (`acctuniqueid`),
  KEY `username` (`username`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `acctsessionid` (`acctsessionid`),
  KEY `acctsessiontime` (`acctsessiontime`),
  KEY `acctstarttime` (`acctstarttime`),
  KEY `acctinterval` (`acctinterval`),
  KEY `acctstoptime` (`acctstoptime`),
  KEY `nasipaddress` (`nasipaddress`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radacct`
--

LOCK TABLES `radacct` WRITE;
/*!40000 ALTER TABLE `radacct` DISABLE KEYS */;
INSERT INTO `radacct` VALUES
(1,'173143488900000001','de90618f94be436f2a4677c0719588b5','Hj','','','10.10.10.1','1','Wireless-802.11','2024-11-12 16:13:46','2024-11-12 16:24:46','2024-11-12 16:25:26',60,700,'','','',2736525,6816037,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(2,'173143559200000001','a62a3750f81aa781c822fba29c892179','3MJ0','','','10.10.10.1','1','Wireless-802.11','2024-11-12 16:25:43','2024-11-12 16:35:43','2024-11-12 16:35:46',60,603,'','','',2026198,13876715,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Session-Timeout','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(3,'173143614700000003','8a1821d74168f096b85ff4a31a3defa8','82-A8-16-07-21-3F','','','10.10.10.1','3','Wireless-802.11','2024-11-12 16:34:41','2024-11-12 17:10:43','2024-11-13 02:06:43',60,34322,'','','',74447,130804,'B4-E2-65-C4-B3-C9','82-A8-16-07-21-3F','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.102'),
(4,'173143621200000001','1546a460f95d87d3c4ec4e3127f7b137','mutiara','','','10.10.10.1','1','Wireless-802.11','2024-11-12 16:40:05','2024-11-12 17:10:07','2024-11-13 02:06:43',300,33998,'','','',27283736,121064008,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(5,'173143841100000002','5ac6ff9b60c6b3152ba6967586f16c00','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-13 02:09:07','2024-11-13 02:19:07',NULL,300,600,'','','',4122176,70459897,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','','','',NULL,NULL,NULL,NULL,'10.10.10.101');
/*!40000 ALTER TABLE `radacct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radcheck`
--

DROP TABLE IF EXISTS `radcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `attribute` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `op` char(2) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '==',
  `value` varchar(253) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radcheck`
--

LOCK TABLES `radcheck` WRITE;
/*!40000 ALTER TABLE `radcheck` DISABLE KEYS */;
INSERT INTO `radcheck` VALUES
(1,'hj','Auth-Type',':=','Accept'),
(2,'82-A8-16-07-21-3F','Auth-Type',':=','Accept'),
(3,'4C-24-CE-8B-A5-50','Auth-Type',':=','Accept'),
(4,'3C-F5-91-59-F5-DC','Auth-Type',':=','Accept'),
(5,'0A-24-69-47-79-F3','Auth-Type',':=','Accept'),
(6,'3MJ0','Auth-Type',':=','Accept'),
(7,'3MJ0','Expiration',':=','14 Nov 2024 01:20:09');
/*!40000 ALTER TABLE `radcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupbw`
--

DROP TABLE IF EXISTS `radgroupbw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupbw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(255) NOT NULL,
  `bw_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bw_id` (`bw_id`),
  CONSTRAINT `radgroupbw_ibfk_1` FOREIGN KEY (`bw_id`) REFERENCES `bandwidth` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupbw`
--

LOCK TABLES `radgroupbw` WRITE;
/*!40000 ALTER TABLE `radgroupbw` DISABLE KEYS */;
INSERT INTO `radgroupbw` VALUES
(1,'Harian',1),
(2,'Mingguan',2);
/*!40000 ALTER TABLE `radgroupbw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupcheck`
--

DROP TABLE IF EXISTS `radgroupcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `attribute` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `op` char(2) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '==',
  `value` varchar(253) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupcheck`
--

LOCK TABLES `radgroupcheck` WRITE;
/*!40000 ALTER TABLE `radgroupcheck` DISABLE KEYS */;
INSERT INTO `radgroupcheck` VALUES
(1,'Admin','Auth-Type',':=','Accept'),
(2,'Admin','Simultaneous-Use',':=','1'),
(10,'TRIAL','Access-Period',':=','86400'),
(9,'TRIAL','Simultaneous-Use',':=','1'),
(8,'TRIAL','Max-All-Session',':=','600'),
(7,'TRIAL','Auth-Type',':=','Accept'),
(11,'Harian','Auth-Type',':=','Accept'),
(12,'Harian','Max-All-Session',':=','86400'),
(13,'Harian','Simultaneous-Use',':=','1'),
(14,'Mingguan','Auth-Type',':=','Accept'),
(15,'Mingguan','Max-All-Session',':=','604800'),
(16,'Mingguan','Simultaneous-Use',':=','1');
/*!40000 ALTER TABLE `radgroupcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupreply`
--

DROP TABLE IF EXISTS `radgroupreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `attribute` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `op` char(2) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '=',
  `value` varchar(253) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupreply`
--

LOCK TABLES `radgroupreply` WRITE;
/*!40000 ALTER TABLE `radgroupreply` DISABLE KEYS */;
INSERT INTO `radgroupreply` VALUES
(1,'Admin','Acct-Interim-Interval',':=','60'),
(5,'TRIAL','Acct-Interim-Interval',':=','60'),
(4,'TRIAL','Idle-Timeout',':=','10'),
(6,'Harian','WISPr-Bandwidth-Max-Down',':=','255000'),
(7,'Harian','WISPr-Bandwidth-Max-Up',':=','255000'),
(8,'Harian','Acct-Interim-Interval',':=','60'),
(9,'Mingguan','WISPr-Bandwidth-Max-Down',':=','7340032'),
(10,'Mingguan','WISPr-Bandwidth-Max-Up',':=','7340032'),
(11,'Mingguan','Acct-Interim-Interval',':=','60');
/*!40000 ALTER TABLE `radgroupreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radpostauth`
--

DROP TABLE IF EXISTS `radpostauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radpostauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `pass` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `reply` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `authdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radpostauth`
--

LOCK TABLES `radpostauth` WRITE;
/*!40000 ALTER TABLE `radpostauth` DISABLE KEYS */;
INSERT INTO `radpostauth` VALUES
(1,'Hj','','Access-Accept','2024-11-12 18:08:11'),
(2,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 18:20:00'),
(3,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 18:20:00'),
(4,'3MJ0','y=3D3D=3D80','Access-Accept','2024-11-12 18:20:09'),
(5,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-12 18:29:07'),
(6,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 18:34:21'),
(7,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 18:34:21'),
(8,'mutiara','','Access-Accept','2024-11-12 18:34:30'),
(9,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-12 19:07:35'),
(10,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-12 19:07:37'),
(11,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 19:07:38'),
(12,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 19:07:39'),
(13,'houjie','','Access-Accept','2024-11-12 19:09:37');
/*!40000 ALTER TABLE `radpostauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radreply`
--

DROP TABLE IF EXISTS `radreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `attribute` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `op` char(2) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '=',
  `value` varchar(253) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radreply`
--

LOCK TABLES `radreply` WRITE;
/*!40000 ALTER TABLE `radreply` DISABLE KEYS */;
/*!40000 ALTER TABLE `radreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radusergroup`
--

DROP TABLE IF EXISTS `radusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radusergroup` (
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `groupname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `priority` int(11) NOT NULL DEFAULT 1,
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radusergroup`
--

LOCK TABLES `radusergroup` WRITE;
/*!40000 ALTER TABLE `radusergroup` DISABLE KEYS */;
INSERT INTO `radusergroup` VALUES
('hj','Admin',0),
('82-A8-16-07-21-3F','Admin',0),
('4C-24-CE-8B-A5-50','Admin',0),
('3C-F5-91-59-F5-DC','Admin',0),
('0A-24-69-47-79-F3','Admin',0),
('3MJ0','TRIAL',0);
/*!40000 ALTER TABLE `radusergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topup`
--

DROP TABLE IF EXISTS `topup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topup` (
  `id` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` enum('Accept','Reject','Pending') NOT NULL,
  `date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topup`
--

LOCK TABLES `topup` WRITE;
/*!40000 ALTER TABLE `topup` DISABLE KEYS */;
/*!40000 ALTER TABLE `topup` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`radmon`@`localhost`*/ /*!50003 TRIGGER `before_insert_topup` BEFORE INSERT ON `topup` FOR EACH ROW
BEGIN
    SET NEW.id = CONCAT('TRX', LPAD(FLOOR(RAND() * 999), 3, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `userbillinfo`
--

DROP TABLE IF EXISTS `userbillinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userbillinfo` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `planName` varchar(128) DEFAULT NULL,
  `hotspot_id` int(32) DEFAULT NULL,
  `hotspotlocation` varchar(32) DEFAULT NULL,
  `contactperson` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip` varchar(200) DEFAULT NULL,
  `paymentmethod` varchar(200) DEFAULT NULL,
  `cash` varchar(200) DEFAULT NULL,
  `creditcardname` varchar(200) DEFAULT NULL,
  `creditcardnumber` varchar(200) DEFAULT NULL,
  `creditcardverification` varchar(200) DEFAULT NULL,
  `creditcardtype` varchar(200) DEFAULT NULL,
  `creditcardexp` varchar(200) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `changeuserbillinfo` varchar(128) DEFAULT NULL,
  `lead` varchar(200) DEFAULT NULL,
  `coupon` varchar(200) DEFAULT NULL,
  `ordertaker` varchar(200) DEFAULT NULL,
  `billstatus` varchar(200) DEFAULT NULL,
  `lastbill` date NOT NULL DEFAULT '0000-00-00',
  `nextbill` date NOT NULL DEFAULT '0000-00-00',
  `nextinvoicedue` int(32) DEFAULT NULL,
  `billdue` int(32) DEFAULT NULL,
  `postalinvoice` varchar(8) DEFAULT NULL,
  `faxinvoice` varchar(8) DEFAULT NULL,
  `emailinvoice` varchar(8) DEFAULT NULL,
  `batch_id` int(32) DEFAULT NULL,
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `planname` (`planName`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userbillinfo`
--

LOCK TABLES `userbillinfo` WRITE;
/*!40000 ALTER TABLE `userbillinfo` DISABLE KEYS */;
INSERT INTO `userbillinfo` VALUES
(1,'hj','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:07:01','radmon','0000-00-00 00:00:00',NULL),
(2,'82-A8-16-07-21-3F','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:10:42','radmon','0000-00-00 00:00:00',NULL),
(3,'4C-24-CE-8B-A5-50','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:11:16','radmon','0000-00-00 00:00:00',NULL),
(4,'3C-F5-91-59-F5-DC','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:11:47','radmon','0000-00-00 00:00:00',NULL),
(5,'0A-24-69-47-79-F3','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:12:44','radmon','0000-00-00 00:00:00',NULL),
(6,'3MJ0','TRIAL',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:20:09','administrator','0000-00-00 00:00:00',NULL);
/*!40000 ALTER TABLE `userbillinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userinfo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `firstname` varchar(200) DEFAULT NULL,
  `lastname` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `department` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `workphone` varchar(200) DEFAULT NULL,
  `homephone` varchar(200) DEFAULT NULL,
  `mobilephone` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip` varchar(200) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `changeuserinfo` varchar(128) DEFAULT NULL,
  `portalloginpassword` varchar(128) DEFAULT '',
  `enableportallogin` int(32) DEFAULT 0,
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userinfo`
--

LOCK TABLES `userinfo` WRITE;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` VALUES
(1,'hj','','','','','','','','','','','','','','','0','',0,'2024-11-13 01:07:01','radmon','0000-00-00 00:00:00',NULL),
(2,'82-A8-16-07-21-3F','rata','','','','','','','','','','','','','','0','',0,'2024-11-13 01:10:42','radmon','0000-00-00 00:00:00',NULL),
(3,'4C-24-CE-8B-A5-50','Tivi','','','','','','','','','','','','','','0','',0,'2024-11-13 01:11:16','radmon','0000-00-00 00:00:00',NULL),
(4,'3C-F5-91-59-F5-DC','Mama','','','','','','','','','','','','','','0','',0,'2024-11-13 01:11:47','radmon','0000-00-00 00:00:00',NULL),
(5,'0A-24-69-47-79-F3','Ido','','','','','','','','','','','','','','0','',0,'2024-11-13 01:12:44','radmon','0000-00-00 00:00:00',NULL),
(6,'3MJ0','','','','','','','','','','','','','','','0','',0,'2024-11-13 01:20:09','administrator','0000-00-00 00:00:00',NULL);
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-13  2:22:11
