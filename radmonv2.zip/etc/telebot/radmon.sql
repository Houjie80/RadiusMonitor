-- MariaDB dump 10.19  Distrib 10.9.3-MariaDB, for Linux (aarch64)
--
-- Host: localhost    Database: radmon
-- ------------------------------------------------------
-- Server version	10.9.3-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bandwidth`
--

DROP TABLE IF EXISTS `bandwidth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bandwidth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `rate_down` int(11) DEFAULT 0,
  `rate_up` int(11) DEFAULT 0,
  `creation_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bandwidth`
--

LOCK TABLES `bandwidth` WRITE;
/*!40000 ALTER TABLE `bandwidth` DISABLE KEYS */;
INSERT INTO `bandwidth` VALUES
(1,'Harian',255000,255000,'2024-11-13 01:15:10'),
(2,'Keluarga',7340032,7340032,'2024-11-13 01:15:26');
/*!40000 ALTER TABLE `bandwidth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_history`
--

DROP TABLE IF EXISTS `batch_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_history` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `batch_name` varchar(64) DEFAULT NULL COMMENT 'an identifier name of the batch instance',
  `batch_description` varchar(256) DEFAULT NULL COMMENT 'general description of the entry',
  `hotspot_id` int(32) DEFAULT 0 COMMENT 'the hotspot business id associated with this batch instance',
  `batch_status` varchar(128) NOT NULL DEFAULT 'Pending' COMMENT 'the batch status',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `batch_name` (`batch_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_history`
--

LOCK TABLES `batch_history` WRITE;
/*!40000 ALTER TABLE `batch_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_plans`
--

DROP TABLE IF EXISTS `billing_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_plans` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `planName` varchar(128) DEFAULT NULL,
  `planId` varchar(128) DEFAULT NULL,
  `planType` varchar(128) DEFAULT NULL,
  `planTimeBank` varchar(128) DEFAULT NULL,
  `planTimeType` varchar(128) DEFAULT NULL,
  `planTimeRefillCost` varchar(128) DEFAULT NULL,
  `planBandwidthUp` varchar(128) DEFAULT NULL,
  `planBandwidthDown` varchar(128) DEFAULT NULL,
  `planTrafficTotal` varchar(128) DEFAULT NULL,
  `planTrafficUp` varchar(128) DEFAULT NULL,
  `planTrafficDown` varchar(128) DEFAULT NULL,
  `planTrafficRefillCost` varchar(128) DEFAULT NULL,
  `planRecurring` varchar(128) DEFAULT NULL,
  `planRecurringPeriod` varchar(128) DEFAULT NULL,
  `planRecurringBillingSchedule` varchar(128) NOT NULL DEFAULT 'Fixed',
  `planCost` varchar(128) DEFAULT NULL,
  `planSetupCost` varchar(128) DEFAULT NULL,
  `planTax` varchar(128) DEFAULT NULL,
  `planCurrency` varchar(128) DEFAULT NULL,
  `planGroup` varchar(128) DEFAULT NULL,
  `planActive` varchar(32) NOT NULL DEFAULT 'yes',
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  `planCode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `planName` (`planName`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_plans`
--

LOCK TABLES `billing_plans` WRITE;
/*!40000 ALTER TABLE `billing_plans` DISABLE KEYS */;
INSERT INTO `billing_plans` VALUES
(1,'Admin','Admin','Prepaid','','Accumulative','','','','','','','','No','Never','Fixed','0','','','','','yes','2024-11-13 01:06:40','radmon','2024-11-13 01:06:40','radmon','Adm'),
(2,'TRIAL','TRIAL','Prepaid','86400','Accumulative','','','','','','','','No','Never','Fixed','0','','','','','yes','2024-11-13 01:14:08','radmon','2024-11-13 01:14:36','radmon','Tr'),
(3,'Harian','Harian','Prepaid','86400','Accumulative','','','','','','','','No','Never','Fixed','1000','','','','','yes','2024-11-13 01:16:44','radmon','2024-11-13 22:06:50','radmon','Hr'),
(4,'Mingguan','Mingguan','Prepaid','604800','Accumulative','','','','','','','','No','Never','Fixed','5000','','','','','yes','2024-11-13 01:17:26','radmon','2024-11-17 17:08:03','radmon','Mg');
/*!40000 ALTER TABLE `billing_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `whatsapp_number` varchar(20) DEFAULT NULL,
  `telegram_id` varchar(50) NOT NULL,
  `balance` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES
(1,'Tes','12345','6285643273595','',14000);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income`
--

DROP TABLE IF EXISTS `income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income` (
  `username` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`date`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income`
--

LOCK TABLES `income` WRITE;
/*!40000 ALTER TABLE `income` DISABLE KEYS */;
INSERT INTO `income` VALUES
('7YRWWI',5000,'2024-11-17');
/*!40000 ALTER TABLE `income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nasname` varchar(128) COLLATE utf8mb3_unicode_ci NOT NULL,
  `shortname` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8mb3_unicode_ci DEFAULT 'other',
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'secret',
  `server` varchar(64) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `community` varchar(50) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb3_unicode_ci DEFAULT 'RADIUS Client',
  PRIMARY KEY (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operators`
--

DROP TABLE IF EXISTS `operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operators` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operators`
--

LOCK TABLES `operators` WRITE;
/*!40000 ALTER TABLE `operators` DISABLE KEYS */;
INSERT INTO `operators` VALUES
(1,'root','mutiara');
/*!40000 ALTER TABLE `operators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_requests`
--

DROP TABLE IF EXISTS `otp_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otp_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `whatsapp_number` varchar(20) DEFAULT NULL,
  `otp_code` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_requests`
--

LOCK TABLES `otp_requests` WRITE;
/*!40000 ALTER TABLE `otp_requests` DISABLE KEYS */;
INSERT INTO `otp_requests` VALUES
(1,'6285643273595',972515,'2024-11-17 15:37:58');
/*!40000 ALTER TABLE `otp_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_config`
--

DROP TABLE IF EXISTS `print_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `print_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hsname1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hsname2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hsip` varchar(15) DEFAULT NULL,
  `hsdomain` varchar(255) DEFAULT NULL,
  `hscsn` varchar(20) DEFAULT NULL,
  `hsqrmode` varchar(10) DEFAULT NULL,
  `hsipdomain` varchar(10) DEFAULT NULL,
  `logomode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_config`
--

LOCK TABLES `print_config` WRITE;
/*!40000 ALTER TABLE `print_config` DISABLE KEYS */;
INSERT INTO `print_config` VALUES
(1,'RASYA-','𝗡𝗘𝗧','10.10.10.1','mutiara.wifi','0856-4327-3595','code','domain','text');
/*!40000 ALTER TABLE `print_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radacct`
--

DROP TABLE IF EXISTS `radacct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radacct` (
  `radacctid` bigint(21) NOT NULL AUTO_INCREMENT,
  `acctsessionid` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `groupname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `realm` varchar(64) COLLATE utf8mb3_unicode_ci DEFAULT '',
  `nasipaddress` varchar(15) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `nasportid` varchar(15) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `nasporttype` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctupdatetime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctinterval` int(12) DEFAULT NULL,
  `acctsessiontime` int(12) unsigned DEFAULT NULL,
  `acctauthentic` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `connectinfo_start` varchar(50) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `connectinfo_stop` varchar(50) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `callingstationid` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `servicetype` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedprotocol` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedipv6address` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedipv6prefix` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedinterfaceid` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `delegatedipv6prefix` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `framedipaddress` varchar(15) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`radacctid`),
  UNIQUE KEY `acctuniqueid` (`acctuniqueid`),
  KEY `username` (`username`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `acctsessionid` (`acctsessionid`),
  KEY `acctsessiontime` (`acctsessiontime`),
  KEY `acctstarttime` (`acctstarttime`),
  KEY `acctinterval` (`acctinterval`),
  KEY `acctstoptime` (`acctstoptime`),
  KEY `nasipaddress` (`nasipaddress`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radacct`
--

LOCK TABLES `radacct` WRITE;
/*!40000 ALTER TABLE `radacct` DISABLE KEYS */;
INSERT INTO `radacct` VALUES
(1,'173143488900000001','de90618f94be436f2a4677c0719588b5','Hj','','','10.10.10.1','1','Wireless-802.11','2024-11-12 16:13:46','2024-11-12 16:24:46','2024-11-12 16:25:26',60,700,'','','',2736525,6816037,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(3,'173143614700000003','8a1821d74168f096b85ff4a31a3defa8','82-A8-16-07-21-3F','','','10.10.10.1','3','Wireless-802.11','2024-11-12 16:34:41','2024-11-12 17:10:43','2024-11-13 02:06:43',60,34322,'','','',74447,130804,'B4-E2-65-C4-B3-C9','82-A8-16-07-21-3F','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.102'),
(22,'173173906100000006','4155d6a3f611e0775bd2a4053903153b','3C-F5-91-59-F5-DC','','','10.10.10.1','6','Wireless-802.11','2024-11-16 12:03:50','2024-11-16 12:59:53','2024-11-16 14:34:58',60,9068,'','','',154651,341115,'B4-E2-65-C4-B3-C9','3C-F5-91-59-F5-DC','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.105'),
(4,'173143621200000001','1546a460f95d87d3c4ec4e3127f7b137','mutiara','','','10.10.10.1','1','Wireless-802.11','2024-11-12 16:40:05','2024-11-12 17:10:07','2024-11-13 02:06:43',300,33998,'','','',27283736,121064008,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(5,'173143841100000002','5ac6ff9b60c6b3152ba6967586f16c00','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-13 02:09:07','2024-11-13 21:49:10','2024-11-13 21:52:37',300,71010,'','','',74261348,1297236075,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(6,'173144316200000003','c2bc8d68a66ca95178b05de266b12f72','82-A8-16-07-21-3F','','','10.10.10.1','3','Wireless-802.11','2024-11-13 03:25:32','2024-11-13 23:39:43','2024-11-13 23:41:39',60,72967,'','','',708201448,1664247754,'B4-E2-65-C4-B3-C9','82-A8-16-07-21-3F','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.102'),
(7,'173145132400000004','81de6413eff9416ef2f0b2ba6c2998b5','4C-24-CE-8B-A5-50','','','10.10.10.1','4','Wireless-802.11','2024-11-13 05:41:34','2024-11-13 23:39:43','2024-11-13 23:41:39',60,64805,'','','',112901392,7314887792,'B4-E2-65-C4-B3-C9','4C-24-CE-8B-A5-50','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.103'),
(8,'173151006800000002','505c1bd130209a5bde3ccd2a39ddc61d','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-13 22:01:20','2024-11-13 23:36:22','2024-11-13 23:41:39',300,6019,'','','',20394224,449610696,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(9,'173151612100000002','c2bf41baa0df52245b1df760235da766','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-13 23:53:55','2024-11-14 11:54:12','2024-11-14 18:32:29',300,67114,'','','',17645337,336255348,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(10,'173157960000000007','c700bc22a57c953e03e02d851c39f1b2','4C-24-CE-8B-A5-50','','','10.10.10.1','7','Wireless-802.11','2024-11-14 10:46:30','2024-11-14 11:57:33','2024-11-14 18:32:29',60,27959,'','','',397412,790751,'B4-E2-65-C4-B3-C9','4C-24-CE-8B-A5-50','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.105'),
(11,'173159174600000002','ed46fc0b1eaf9dfc0bd19d57e8eb83b1','ITWG','','','10.10.10.1','2','Wireless-802.11','2024-11-14 18:33:42','2024-11-14 18:34:44','2024-11-14 18:35:24',62,102,'','','',850745,8236065,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(12,'173159185800000002','821d6e856c7beac1af1b8c8776a32821','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-14 18:35:43','2024-11-15 09:45:47','2024-11-15 11:55:29',300,62386,'','','',31735907,336495735,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(13,'173162091300000004','8d6c0131c34b88c6628df30041834f98','82-A8-16-07-21-3F','','','10.10.10.1','4','Wireless-802.11','2024-11-15 02:39:39','2024-11-15 09:48:41','2024-11-15 11:55:29',60,33350,'','','',74240776,100566261,'B4-E2-65-C4-B3-C9','82-A8-16-07-21-3F','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.103'),
(14,'173162451400000005','1485b7399231d7eb27a3fd8ea09bf5c1','4C-24-CE-8B-A5-50','','','10.10.10.1','5','Wireless-802.11','2024-11-15 03:39:42','2024-11-15 09:48:44','2024-11-15 11:55:29',60,29747,'','','',33124894,2167725938,'B4-E2-65-C4-B3-C9','4C-24-CE-8B-A5-50','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.105'),
(15,'173165450100000002','e686ea8f8f0b4d2b3511c13391fb4fc0','82-A8-16-07-21-3F','','','10.10.10.1','2','Wireless-802.11','2024-11-15 11:56:24','2024-11-15 15:03:28','2024-11-15 17:15:29',60,19145,'','','',13344822,257631632,'B4-E2-65-C4-B3-C9','82-A8-16-07-21-3F','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.103'),
(16,'173165469900000003','3631fdb1b09f5d577e6b90900737212a','3C-F5-91-59-F5-DC','','','10.10.10.1','3','Wireless-802.11','2024-11-15 11:59:42','2024-11-15 15:03:46','2024-11-15 17:15:29',60,18947,'','','',1204997,55492771,'B4-E2-65-C4-B3-C9','3C-F5-91-59-F5-DC','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(17,'173165991800000005','5fe4c13b1c4cdf0e82107c921dd5194d','4C-24-CE-8B-A5-50','','','10.10.10.1','5','Wireless-802.11','2024-11-15 13:26:41','2024-11-15 15:03:43','2024-11-15 17:15:29',60,13728,'','','',23736525,1719388707,'B4-E2-65-C4-B3-C9','4C-24-CE-8B-A5-50','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.105'),
(18,'173166255100000006','c62fd63fc0006f0196726bbf6584795d','houjie','','','10.10.10.1','6','Wireless-802.11','2024-11-15 14:10:49','2024-11-15 15:00:52','2024-11-15 17:15:29',300,11080,'','','',6742774,23447461,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.104'),
(19,'173166573600000002','37c2668085b2988120a1407b140240e1','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-15 17:16:37','2024-11-16 12:56:47','2024-11-16 14:34:58',301,76701,'','','',48553357,556980539,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(20,'173166944800000003','adb799fd5fb78dc2e8d24fb7245d8715','4C-24-CE-8B-A5-50','','','10.10.10.1','3','Wireless-802.11','2024-11-15 18:17:30','2024-11-16 12:59:38','2024-11-16 14:34:58',60,73048,'','','',753133,30939951,'B4-E2-65-C4-B3-C9','4C-24-CE-8B-A5-50','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.102'),
(21,'173166995900000004','49cd5091fc21f34e91865c22077b1548','82-A8-16-07-21-3F','','','10.10.10.1','4','Wireless-802.11','2024-11-15 18:26:00','2024-11-16 13:00:08','2024-11-16 14:34:58',60,72538,'','','',1376831726,1246768965,'B4-E2-65-C4-B3-C9','82-A8-16-07-21-3F','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.103'),
(23,'173174251600000003','ea7970b379c4900196a503f8d82e1132','3C-F5-91-59-F5-DC','','','10.10.10.1','3','Wireless-802.11','2024-11-16 14:35:29','2024-11-16 22:09:32','2024-11-16 14:35:27',60,27243,'','','',4835202,106310673,'B4-E2-65-C4-B3-C9','3C-F5-91-59-F5-DC','Clear-Stale Session','','',NULL,NULL,NULL,NULL,'10.10.10.102'),
(24,'173174250400000002','13df12abf8a80cf62074cd40297b2e87','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-16 14:41:23','2024-11-16 22:06:26','2024-11-16 23:14:42',300,30799,'','','',74558133,1325782276,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(25,'173175037300000004','3484af1aeebcb3e533b2d3bb2edf3382','4C-24-CE-8B-A5-50','','','10.10.10.1','4','Wireless-802.11','2024-11-16 15:42:50','2024-11-16 22:09:53','2024-11-16 23:14:42',60,27112,'','','',41210995,2018640446,'B4-E2-65-C4-B3-C9','4C-24-CE-8B-A5-50','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.103'),
(26,'173177369500000003','ecd1778803da81022aef380bf1861cc9','3C-F5-91-59-F5-DC','','','10.10.10.1','3','Wireless-802.11','2024-11-16 23:15:09','2024-11-17 09:39:10','2024-11-16 23:15:08',60,37441,'','','',1766998,5220707,'B4-E2-65-C4-B3-C9','3C-F5-91-59-F5-DC','Clear-Stale Session','','',NULL,NULL,NULL,NULL,'10.10.10.102'),
(27,'173177368300000001','190fd76d158339d8fd4c0b900777168d','houjie','','','10.10.10.1','1','Wireless-802.11','2024-11-16 23:15:09','2024-11-16 23:25:09','2024-11-16 23:28:17',300,788,'','','',1740933,11834417,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(28,'173178039000000001','d4770ebb14bd2832726a9494eebe393b','MU0K','','','10.10.10.1','1','Wireless-802.11','2024-11-16 23:28:47','2024-11-16 23:29:48','2024-11-16 23:30:13',61,86,'','','',885704,8782582,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(29,'173178050600000001','a2808d6d9cb27a593ff53a21adc72a72','houjie','','','10.10.10.1','1','Wireless-802.11','2024-11-16 23:30:34','2024-11-17 09:35:37','2024-11-17 11:18:17',300,42463,'','','',62543544,1264087446,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(30,'173178220600000006','642d2bcc64daca13d2346e01abf9672b','4C-24-CE-8B-A5-50','','','10.10.10.1','6','Wireless-802.11','2024-11-16 23:58:34','2024-11-17 09:38:37','2024-11-17 11:18:17',60,40783,'','','',25684432,1543530496,'B4-E2-65-C4-B3-C9','4C-24-CE-8B-A5-50','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.103'),
(31,'173178834700000007','6ea65ec083e3cdc7b7cf75554747b247','82-A8-16-07-21-3F','','','10.10.10.1','7','Wireless-802.11','2024-11-17 01:40:56','2024-11-17 09:38:58','2024-11-17 11:18:17',60,34641,'','','',409334730,367811110,'B4-E2-65-C4-B3-C9','82-A8-16-07-21-3F','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.104'),
(32,'173182070400000003','1e735ce20f330208cd4f336b1ec1915a','4C-24-CE-8B-A5-50','','','10.10.10.1','3','Wireless-802.11','2024-11-17 11:32:21','2024-11-17 21:50:28','2024-11-17 21:51:12',60,37131,'','','',92929537,4387212005,'B4-E2-65-C4-B3-C9','4C-24-CE-8B-A5-50','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.102'),
(33,'173181711000000002','5590278742c1fd626a06321af10c79eb','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-17 11:51:08','2024-11-17 13:26:08','2024-11-17 13:29:15',300,5887,'','','',13002909,171674284,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(34,'173182750500000004','8900037fd23c3a0664a3056f78ff66d6','3C-F5-91-59-F5-DC','','','10.10.10.1','4','Wireless-802.11','2024-11-17 13:25:42','2024-11-17 21:50:49','2024-11-17 21:51:12',60,30330,'','','',11019103,80185580,'B4-E2-65-C4-B3-C9','3C-F5-91-59-F5-DC','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.103'),
(35,'173182771900000002','859bbce4ad7665cb0c8a2d73237349df','rasya','','','10.10.10.1','2','Wireless-802.11','2024-11-17 13:32:24','2024-11-17 14:25:27','2024-11-17 14:25:42',60,3198,'','','',8110231,150728179,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(36,'173183110600000002','1b6fd393dbe8a105d922ba33ae28b005','houjie','','','10.10.10.1','2','Wireless-802.11','2024-11-17 14:26:11','2024-11-17 16:16:13','2024-11-17 16:18:05',300,6714,'','','',12703177,203727163,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(37,'173183784900000002','385b4b94f7f79462882f9c2208c30271','rasya','','','10.10.10.1','2','Wireless-802.11','2024-11-17 16:20:43','2024-11-17 16:22:43','2024-11-17 16:22:47',60,124,'','','',372709,3395263,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(38,'173183813100000002','c398e5eb01754a85fcf6e980ecc63a06','Rasya','','','10.10.10.1','2','Wireless-802.11','2024-11-17 16:24:54','2024-11-17 18:06:55','2024-11-17 18:06:59',60,6125,'','','',14458373,433827361,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','Admin-Reset','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(39,'173184438300000002','3501e89349b0aab198192f551f452240','rasya','','','10.10.10.1','2','Wireless-802.11','2024-11-17 18:08:31','2024-11-17 21:50:34','2024-11-17 21:51:12',60,13361,'','','',2039358,11979660,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','NAS-Reboot','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(40,'173185790800000005','bc7e9509f99ef5f208b0e17f8580a0ec','3C-F5-91-59-F5-DC','','','10.10.10.1','5','Wireless-802.11','2024-11-17 22:38:28','2024-11-17 23:43:29',NULL,60,3901,'','','',469803,3363842,'B4-E2-65-C4-B3-C9','3C-F5-91-59-F5-DC','','','',NULL,NULL,NULL,NULL,'10.10.10.103'),
(41,'173185784000000004','74505c920bdb0b63a57746c9cd9e6735','7YRWWI','','','10.10.10.1','4','Wireless-802.11','2024-11-17 22:43:09','2024-11-17 23:43:11',NULL,60,3602,'','','',10016198,87581496,'B4-E2-65-C4-B3-C9','7C-2A-DB-9F-82-B6','','','',NULL,NULL,NULL,NULL,'10.10.10.101'),
(42,'173185842700000007','0998ec7db8aad4cb6f984ba4e337d86a','82-A8-16-07-21-3F','','','10.10.10.1','7','Wireless-802.11','2024-11-17 22:47:08','2024-11-17 23:43:08',NULL,60,3360,'','','',4103856,114703753,'B4-E2-65-C4-B3-C9','82-A8-16-07-21-3F','','','',NULL,NULL,NULL,NULL,'10.10.10.105');
/*!40000 ALTER TABLE `radacct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radcheck`
--

DROP TABLE IF EXISTS `radcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `attribute` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `op` char(2) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '==',
  `value` varchar(253) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radcheck`
--

LOCK TABLES `radcheck` WRITE;
/*!40000 ALTER TABLE `radcheck` DISABLE KEYS */;
INSERT INTO `radcheck` VALUES
(1,'hj','Auth-Type',':=','Accept'),
(2,'82-A8-16-07-21-3F','Auth-Type',':=','Accept'),
(3,'4C-24-CE-8B-A5-50','Auth-Type',':=','Accept'),
(4,'3C-F5-91-59-F5-DC','Auth-Type',':=','Accept'),
(5,'0A-24-69-47-79-F3','Auth-Type',':=','Accept'),
(13,'MU0K','Expiration',':=','18 Nov 2024 01:06:59'),
(12,'MU0K','Auth-Type',':=','Accept'),
(8,'rasya','Auth-Type',':=','Accept'),
(9,'rasya2','Auth-Type',':=','Accept'),
(10,'ITWG','Auth-Type',':=','Accept'),
(11,'ITWG','Expiration',':=','15 Nov 2024 20:42:36'),
(22,'JMDXLB','Auth-Type',':=','Accept'),
(21,'7YRWWI','Expiration',':=','24 Nov 2024 22:43:08'),
(20,'7YRWWI','Auth-Type',':=','Accept'),
(19,'829132','Auth-Type',':=','Accept');
/*!40000 ALTER TABLE `radcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupbw`
--

DROP TABLE IF EXISTS `radgroupbw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupbw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(255) NOT NULL,
  `bw_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bw_id` (`bw_id`),
  CONSTRAINT `radgroupbw_ibfk_1` FOREIGN KEY (`bw_id`) REFERENCES `bandwidth` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupbw`
--

LOCK TABLES `radgroupbw` WRITE;
/*!40000 ALTER TABLE `radgroupbw` DISABLE KEYS */;
INSERT INTO `radgroupbw` VALUES
(3,'Harian',1),
(4,'Mingguan',2);
/*!40000 ALTER TABLE `radgroupbw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupcheck`
--

DROP TABLE IF EXISTS `radgroupcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `attribute` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `op` char(2) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '==',
  `value` varchar(253) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupcheck`
--

LOCK TABLES `radgroupcheck` WRITE;
/*!40000 ALTER TABLE `radgroupcheck` DISABLE KEYS */;
INSERT INTO `radgroupcheck` VALUES
(1,'Admin','Auth-Type',':=','Accept'),
(2,'Admin','Simultaneous-Use',':=','1'),
(10,'TRIAL','Access-Period',':=','86400'),
(9,'TRIAL','Simultaneous-Use',':=','1'),
(8,'TRIAL','Max-All-Session',':=','600'),
(7,'TRIAL','Auth-Type',':=','Accept'),
(23,'Harian','Simultaneous-Use',':=','1'),
(22,'Harian','Max-All-Session',':=','86400'),
(31,'Mingguan','Simultaneous-Use',':=','1'),
(30,'Mingguan','Max-All-Session',':=','604800'),
(24,'Harian','Access-Period',':=','86400'),
(21,'Harian','Auth-Type',':=','Accept'),
(29,'Mingguan','Auth-Type',':=','Accept'),
(32,'Mingguan','Access-Period',':=','604800');
/*!40000 ALTER TABLE `radgroupcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupreply`
--

DROP TABLE IF EXISTS `radgroupreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `attribute` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `op` char(2) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '=',
  `value` varchar(253) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupreply`
--

LOCK TABLES `radgroupreply` WRITE;
/*!40000 ALTER TABLE `radgroupreply` DISABLE KEYS */;
INSERT INTO `radgroupreply` VALUES
(1,'Admin','Acct-Interim-Interval',':=','60'),
(5,'TRIAL','Acct-Interim-Interval',':=','60'),
(4,'TRIAL','Idle-Timeout',':=','10'),
(14,'Harian','WISPr-Bandwidth-Max-Up',':=','255000'),
(13,'Harian','WISPr-Bandwidth-Max-Down',':=','255000'),
(18,'Mingguan','WISPr-Bandwidth-Max-Up',':=','7340032'),
(17,'Mingguan','WISPr-Bandwidth-Max-Down',':=','7340032'),
(15,'Harian','Acct-Interim-Interval',':=','60'),
(19,'Mingguan','Acct-Interim-Interval',':=','60');
/*!40000 ALTER TABLE `radgroupreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radpostauth`
--

DROP TABLE IF EXISTS `radpostauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radpostauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `pass` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `reply` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `authdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=218 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radpostauth`
--

LOCK TABLES `radpostauth` WRITE;
/*!40000 ALTER TABLE `radpostauth` DISABLE KEYS */;
INSERT INTO `radpostauth` VALUES
(1,'Hj','','Access-Accept','2024-11-12 18:08:11'),
(2,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 18:20:00'),
(3,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 18:20:00'),
(4,'3MJ0','y=3D3D=3D80','Access-Accept','2024-11-12 18:20:09'),
(5,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-12 18:29:07'),
(6,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 18:34:21'),
(7,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 18:34:21'),
(8,'mutiara','','Access-Accept','2024-11-12 18:34:30'),
(9,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-12 19:07:35'),
(10,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-12 19:07:37'),
(11,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 19:07:38'),
(12,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-12 19:07:39'),
(13,'houjie','','Access-Accept','2024-11-12 19:09:37'),
(14,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-12 20:26:02'),
(15,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-12 22:42:04'),
(16,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-13 00:11:24'),
(17,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-13 00:11:24'),
(18,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-13 07:07:21'),
(19,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-13 12:11:26'),
(20,'0C-98-38-6A-1E-F7','0C-98-38-6A-1E-F7','Access-Reject','2024-11-13 12:38:43'),
(21,'0C-98-38-6A-1E-F7','0C-98-38-6A-1E-F7','Access-Reject','2024-11-13 12:38:43'),
(22,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-13 14:53:14'),
(23,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-13 14:53:14'),
(24,'rita','','Access-Reject','2024-11-13 15:01:07'),
(25,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-13 15:01:43'),
(26,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-13 15:01:43'),
(27,'houjie','','Access-Accept','2024-11-13 15:01:50'),
(28,'A6-B3-76-2A-00-B9','A6-B3-76-2A-00-B9','Access-Reject','2024-11-13 15:02:17'),
(29,'A6-B3-76-2A-00-B9','A6-B3-76-2A-00-B9','Access-Reject','2024-11-13 15:02:17'),
(30,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-13 16:42:02'),
(31,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-13 16:42:06'),
(32,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-13 16:42:07'),
(33,'A6-B3-76-2A-00-B9','A6-B3-76-2A-00-B9','Access-Reject','2024-11-13 23:23:51'),
(34,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-13 23:26:20'),
(35,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-13 23:26:20'),
(36,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-13 23:27:16'),
(37,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-13 23:27:16'),
(38,'houjie','','Access-Accept','2024-11-13 23:27:27'),
(39,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:09'),
(40,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:09'),
(41,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:09'),
(42,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:09'),
(43,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:10'),
(44,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:10'),
(45,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:10'),
(46,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:10'),
(47,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:11'),
(48,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-13 23:35:11'),
(49,'DA-DC-B0-0B-32-04','DA-DC-B0-0B-32-04','Access-Reject','2024-11-14 00:09:51'),
(50,'DA-DC-B0-0B-32-04','DA-DC-B0-0B-32-04','Access-Reject','2024-11-14 00:09:51'),
(51,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-14 10:20:00'),
(52,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-14 10:20:02'),
(53,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-14 10:20:02'),
(54,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-14 11:13:56'),
(55,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-14 11:13:57'),
(56,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-14 11:13:57'),
(57,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-14 11:13:57'),
(58,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-14 11:13:58'),
(59,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-14 11:13:58'),
(60,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-14 11:13:58'),
(61,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-14 11:13:58'),
(62,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-14 11:15:18'),
(63,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-14 11:26:22'),
(64,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-14 11:32:53'),
(65,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-14 11:32:58'),
(66,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-14 13:41:54'),
(67,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-14 13:41:56'),
(68,'Houjie','','Access-Reject','2024-11-14 13:42:25'),
(69,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-14 13:42:30'),
(70,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-14 13:42:30'),
(71,'ITWG','F=3D1CX','Access-Accept','2024-11-14 13:42:36'),
(72,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-14 13:44:30'),
(73,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-14 13:44:30'),
(74,'houjie','','Access-Accept','2024-11-14 13:44:37'),
(75,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-14 21:48:33'),
(76,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-14 21:48:33'),
(77,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-14 22:48:36'),
(78,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-15 01:41:27'),
(79,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-15 01:42:31'),
(80,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-15 04:05:32'),
(81,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-15 04:05:32'),
(82,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-15 04:51:24'),
(83,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-15 04:51:24'),
(84,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-15 04:55:56'),
(85,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-15 04:55:57'),
(86,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-15 07:08:21'),
(87,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-15 07:11:39'),
(88,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-15 07:11:39'),
(89,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-15 07:29:13'),
(90,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-15 07:29:13'),
(91,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-15 08:38:38'),
(92,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-15 09:22:31'),
(93,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-15 09:22:31'),
(94,'houjie','','Access-Accept','2024-11-15 09:22:45'),
(95,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-15 10:15:54'),
(96,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-15 10:15:57'),
(97,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-15 10:15:57'),
(98,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-15 10:15:57'),
(99,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-15 10:15:57'),
(100,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-15 10:15:58'),
(101,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-15 10:16:27'),
(102,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-15 10:16:27'),
(103,'houjie','','Access-Accept','2024-11-15 10:16:35'),
(104,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-15 11:17:29'),
(105,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-15 11:17:29'),
(106,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-15 11:25:59'),
(107,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-15 15:36:15'),
(108,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-15 15:36:15'),
(109,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-15 15:53:25'),
(110,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-15 15:53:25'),
(111,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-15 23:49:26'),
(112,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-16 06:37:41'),
(113,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-16 07:35:22'),
(114,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-16 07:35:23'),
(115,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-16 07:35:25'),
(116,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-16 08:38:50'),
(117,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-16 08:38:51'),
(118,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-16 08:38:52'),
(119,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-16 08:38:53'),
(120,'houjie','','Access-Accept','2024-11-16 08:44:47'),
(121,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-16 09:46:14'),
(122,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-16 09:46:14'),
(123,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-16 09:46:14'),
(124,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-16 16:15:05'),
(125,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-16 16:15:08'),
(126,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-16 16:15:08'),
(127,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-16 16:15:08'),
(128,'houjie','','Access-Accept','2024-11-16 16:15:09'),
(129,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-16 16:15:09'),
(130,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-16 16:15:10'),
(131,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-16 16:15:11'),
(132,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-16 18:06:51'),
(133,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-16 18:06:51'),
(134,'MU0K','=3D12=3D07X','Access-Accept','2024-11-16 18:06:59'),
(135,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-16 18:08:36'),
(136,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-16 18:08:36'),
(137,'houjie','','Access-Accept','2024-11-16 18:08:46'),
(138,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-16 18:36:46'),
(139,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-16 18:36:46'),
(140,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-16 18:36:46'),
(141,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-16 20:19:07'),
(142,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-16 20:19:08'),
(143,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-16 20:19:08'),
(144,'DA-DC-B0-0B-32-04','DA-DC-B0-0B-32-04','Access-Reject','2024-11-16 20:30:03'),
(145,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-16 21:21:15'),
(146,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-16 21:21:15'),
(147,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-16 23:10:07'),
(148,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-16 23:10:07'),
(149,'16-65-23-5C-8D-13','16-65-23-5C-8D-13','Access-Reject','2024-11-16 23:34:38'),
(150,'16-65-23-5C-8D-13','16-65-23-5C-8D-13','Access-Reject','2024-11-16 23:34:38'),
(151,'CC-2D-83-A1-9C-D2','CC-2D-83-A1-9C-D2','Access-Reject','2024-11-17 00:25:29'),
(152,'CC-2D-83-A1-9C-D2','CC-2D-83-A1-9C-D2','Access-Reject','2024-11-17 00:25:29'),
(153,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-17 03:34:09'),
(154,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 04:18:40'),
(155,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 04:18:41'),
(156,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-17 04:18:43'),
(157,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-17 04:18:44'),
(158,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-17 05:18:24'),
(159,'4C-24-CE-8B-A5-50','4C-24-CE-8B-A5-50','Access-Accept','2024-11-17 05:18:24'),
(160,'houjie','','Access-Accept','2024-11-17 05:37:12'),
(161,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-17 07:11:45'),
(162,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 07:15:34'),
(163,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 07:15:34'),
(164,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 07:16:30'),
(165,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 07:16:30'),
(166,'rasya','','Access-Accept','2024-11-17 07:18:28'),
(167,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 08:11:55'),
(168,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 08:11:55'),
(169,'houjie','','Access-Accept','2024-11-17 08:12:15'),
(170,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-17 08:37:14'),
(171,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-17 08:37:14'),
(172,'DA-DC-B0-0B-32-04','DA-DC-B0-0B-32-04','Access-Reject','2024-11-17 08:44:17'),
(173,'DA-DC-B0-0B-32-04','DA-DC-B0-0B-32-04','Access-Reject','2024-11-17 08:44:17'),
(174,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 10:04:20'),
(175,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 10:04:20'),
(176,'rasya','','Access-Accept','2024-11-17 10:06:46'),
(177,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 10:08:58'),
(178,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 10:08:58'),
(179,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 10:10:10'),
(180,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 10:10:10'),
(181,'Rasya','','Access-Accept','2024-11-17 10:10:58'),
(182,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-17 10:51:43'),
(183,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-17 10:51:44'),
(184,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-17 11:39:43'),
(185,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-17 11:39:43'),
(186,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 11:53:10'),
(187,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 11:53:10'),
(188,'rasya','','Access-Accept','2024-11-17 11:54:35'),
(189,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:39'),
(190,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:39'),
(191,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:39'),
(192,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:39'),
(193,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:39'),
(194,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:40'),
(195,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:40'),
(196,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:40'),
(197,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:40'),
(198,'66-E1-84-71-7A-B2','66-E1-84-71-7A-B2','Access-Reject','2024-11-17 13:06:40'),
(199,'00-0A-F5-89-89-FF','00-0A-F5-89-89-FF','Access-Reject','2024-11-17 14:57:43'),
(200,'00-0A-F5-89-89-FF','00-0A-F5-89-89-FF','Access-Reject','2024-11-17 14:57:43'),
(201,'00-0A-F5-89-89-FF','00-0A-F5-89-89-FF','Access-Reject','2024-11-17 15:37:11'),
(202,'00-0A-F5-89-89-FF','00-0A-F5-89-89-FF','Access-Reject','2024-11-17 15:37:11'),
(203,'28-31-66-86-C1-31','28-31-66-86-C1-31','Access-Reject','2024-11-17 15:37:17'),
(204,'00-0A-F5-89-89-FF','00-0A-F5-89-89-FF','Access-Reject','2024-11-17 15:37:18'),
(205,'C8-3A-35-4E-4D-F8','C8-3A-35-4E-4D-F8','Access-Reject','2024-11-17 15:37:19'),
(206,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 15:37:31'),
(207,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 15:37:36'),
(208,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 15:37:36'),
(209,'3C-F5-91-59-F5-DC','3C-F5-91-59-F5-DC','Access-Accept','2024-11-17 15:38:28'),
(210,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 15:43:03'),
(211,'7C-2A-DB-9F-82-B6','7C-2A-DB-9F-82-B6','Access-Reject','2024-11-17 15:43:03'),
(212,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-17 15:43:06'),
(213,'E0-1F-88-6C-0D-9C','E0-1F-88-6C-0D-9C','Access-Reject','2024-11-17 15:43:06'),
(214,'7YRWWI','','Access-Accept','2024-11-17 15:43:08'),
(215,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-17 15:47:07'),
(216,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-17 15:47:08'),
(217,'82-A8-16-07-21-3F','82-A8-16-07-21-3F','Access-Accept','2024-11-17 15:47:08');
/*!40000 ALTER TABLE `radpostauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radreply`
--

DROP TABLE IF EXISTS `radreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `attribute` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `op` char(2) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '=',
  `value` varchar(253) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radreply`
--

LOCK TABLES `radreply` WRITE;
/*!40000 ALTER TABLE `radreply` DISABLE KEYS */;
/*!40000 ALTER TABLE `radreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radusergroup`
--

DROP TABLE IF EXISTS `radusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radusergroup` (
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `groupname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `priority` int(11) NOT NULL DEFAULT 1,
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radusergroup`
--

LOCK TABLES `radusergroup` WRITE;
/*!40000 ALTER TABLE `radusergroup` DISABLE KEYS */;
INSERT INTO `radusergroup` VALUES
('hj','Admin',0),
('82-A8-16-07-21-3F','Admin',0),
('4C-24-CE-8B-A5-50','Admin',0),
('3C-F5-91-59-F5-DC','Admin',0),
('0A-24-69-47-79-F3','Admin',0),
('3MJ0','TRIAL',0),
('rasya','Admin',0),
('rasya2','Harian',0),
('ITWG','TRIAL',0),
('MU0K','TRIAL',0),
('JMDXLB','Harian',0),
('7YRWWI','Mingguan',0),
('829132','Harian',0);
/*!40000 ALTER TABLE `radusergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topup`
--

DROP TABLE IF EXISTS `topup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topup` (
  `id` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` enum('Accept','Reject','Pending') NOT NULL,
  `date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topup`
--

LOCK TABLES `topup` WRITE;
/*!40000 ALTER TABLE `topup` DISABLE KEYS */;
INSERT INTO `topup` VALUES
('TRX897',1,'Tes',20000,'Accept','2024-11-17 22:39:28');
/*!40000 ALTER TABLE `topup` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`radmon`@`localhost`*/ /*!50003 TRIGGER `before_insert_topup` BEFORE INSERT ON `topup` FOR EACH ROW
BEGIN
    SET NEW.id = CONCAT('TRX', LPAD(FLOOR(RAND() * 999), 3, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `userbillinfo`
--

DROP TABLE IF EXISTS `userbillinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userbillinfo` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `planName` varchar(128) DEFAULT NULL,
  `hotspot_id` int(32) DEFAULT NULL,
  `hotspotlocation` varchar(32) DEFAULT NULL,
  `contactperson` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip` varchar(200) DEFAULT NULL,
  `paymentmethod` varchar(200) DEFAULT NULL,
  `cash` varchar(200) DEFAULT NULL,
  `creditcardname` varchar(200) DEFAULT NULL,
  `creditcardnumber` varchar(200) DEFAULT NULL,
  `creditcardverification` varchar(200) DEFAULT NULL,
  `creditcardtype` varchar(200) DEFAULT NULL,
  `creditcardexp` varchar(200) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `changeuserbillinfo` varchar(128) DEFAULT NULL,
  `lead` varchar(200) DEFAULT NULL,
  `coupon` varchar(200) DEFAULT NULL,
  `ordertaker` varchar(200) DEFAULT NULL,
  `billstatus` varchar(200) DEFAULT NULL,
  `lastbill` date NOT NULL DEFAULT '0000-00-00',
  `nextbill` date NOT NULL DEFAULT '0000-00-00',
  `nextinvoicedue` int(32) DEFAULT NULL,
  `billdue` int(32) DEFAULT NULL,
  `postalinvoice` varchar(8) DEFAULT NULL,
  `faxinvoice` varchar(8) DEFAULT NULL,
  `emailinvoice` varchar(8) DEFAULT NULL,
  `batch_id` int(32) DEFAULT NULL,
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `planname` (`planName`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userbillinfo`
--

LOCK TABLES `userbillinfo` WRITE;
/*!40000 ALTER TABLE `userbillinfo` DISABLE KEYS */;
INSERT INTO `userbillinfo` VALUES
(1,'hj','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:07:01','radmon','0000-00-00 00:00:00',NULL),
(2,'82-A8-16-07-21-3F','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:10:42','radmon','0000-00-00 00:00:00',NULL),
(3,'4C-24-CE-8B-A5-50','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:11:16','radmon','0000-00-00 00:00:00',NULL),
(4,'3C-F5-91-59-F5-DC','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:11:47','radmon','0000-00-00 00:00:00',NULL),
(5,'0A-24-69-47-79-F3','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 01:12:44','radmon','0000-00-00 00:00:00',NULL),
(10,'MU0K','TRIAL',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-17 01:06:59','administrator','0000-00-00 00:00:00',NULL),
(7,'rasya','Admin',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 22:02:48','radmon','0000-00-00 00:00:00',NULL),
(8,'rasya2','Harian',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-13 22:03:20','radmon','0000-00-00 00:00:00',NULL),
(9,'ITWG','TRIAL',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-14 20:42:36','administrator','0000-00-00 00:00:00',NULL),
(18,'JMDXLB','Harian',NULL,NULL,'Tes','','','6285643273595','','','','','','cash','1000','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-17 22:43:43','Tes','0000-00-00 00:00:00',NULL),
(17,'7YRWWI','Mingguan',NULL,NULL,'Tes','','','6285643273595','','','','','','cash','5000','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-17 22:41:42','Tes','0000-00-00 00:00:00',NULL),
(16,'829132','Harian',NULL,NULL,'','','','','','','','','','','','','','','','','','0','','','','','0000-00-00','0000-00-00',0,0,'','','',NULL,'2024-11-17 01:20:50','administrator','0000-00-00 00:00:00',NULL);
/*!40000 ALTER TABLE `userbillinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userinfo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  `firstname` varchar(200) DEFAULT NULL,
  `lastname` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `department` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `workphone` varchar(200) DEFAULT NULL,
  `homephone` varchar(200) DEFAULT NULL,
  `mobilephone` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip` varchar(200) DEFAULT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `changeuserinfo` varchar(128) DEFAULT NULL,
  `portalloginpassword` varchar(128) DEFAULT '',
  `enableportallogin` int(32) DEFAULT 0,
  `creationdate` datetime DEFAULT '0000-00-00 00:00:00',
  `creationby` varchar(128) DEFAULT NULL,
  `updatedate` datetime DEFAULT '0000-00-00 00:00:00',
  `updateby` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userinfo`
--

LOCK TABLES `userinfo` WRITE;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` VALUES
(1,'hj','','','','','','','','','','','','','','','0','',0,'2024-11-13 01:07:01','radmon','0000-00-00 00:00:00',NULL),
(2,'82-A8-16-07-21-3F','rata','','','','','','','','','','','','','','0','',0,'2024-11-13 01:10:42','radmon','0000-00-00 00:00:00',NULL),
(3,'4C-24-CE-8B-A5-50','Tivi','','','','','','','','','','','','','','0','',0,'2024-11-13 01:11:16','radmon','0000-00-00 00:00:00',NULL),
(4,'3C-F5-91-59-F5-DC','Mama','','','','','','','','','','','','','','0','',0,'2024-11-13 01:11:47','radmon','0000-00-00 00:00:00',NULL),
(5,'0A-24-69-47-79-F3','Ido','','','','','','','','','','','','','','0','',0,'2024-11-13 01:12:44','radmon','0000-00-00 00:00:00',NULL),
(10,'MU0K','','','','','','','','','','','','','','','0','',0,'2024-11-17 01:06:59','administrator','0000-00-00 00:00:00',NULL),
(7,'rasya','','','','','','','','','','','','','','','0','',0,'2024-11-13 22:02:48','radmon','0000-00-00 00:00:00',NULL),
(8,'rasya2','','','','','','','','','','','','','','','0','',0,'2024-11-13 22:03:20','radmon','0000-00-00 00:00:00',NULL),
(9,'ITWG','','','','','','','','','','','','','','','0','',0,'2024-11-14 20:42:36','administrator','0000-00-00 00:00:00',NULL),
(18,'JMDXLB','Tes','','','','','','','6285643273595','','','','','','','0','',0,'2024-11-17 22:43:43','Tes','0000-00-00 00:00:00',NULL),
(17,'7YRWWI','Tes','','','','','','','6285643273595','','','','','','','0','',0,'2024-11-17 22:41:42','Tes','0000-00-00 00:00:00',NULL),
(16,'829132','','','','','','','','','','','','','','','0','',0,'2024-11-17 01:20:50','administrator','0000-00-00 00:00:00',NULL);
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-17 23:43:47
