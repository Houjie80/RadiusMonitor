document.write('WEKTU UJI COBA WES NTEK,SESOK MANEH.PINGIN SUE : <a href="https://t.me/RasyaWRTNET_bot" class="btn btn-text-primary" >telegram')
//Sesuaikan
//Jangan Menghapus kode scriptnya