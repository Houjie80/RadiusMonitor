document.write('Berlangganan Wifi Rumah Silahkan Klik Menu Kontak')
//Sesuaikan
//Jangan Menghapus kode scriptnya